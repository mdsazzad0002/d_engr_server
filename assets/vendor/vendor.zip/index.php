<script type="text/javascript">
	window.location.href='/';
</script>